package com.inventory;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Scanner;

public class InventoryManagement {

    // Update USER and PASSWORD according to your MySQL installation.
    private static final String URL = "jdbc:mysql://localhost:3306/retail_db";
    private static final String USER = "root";
    private static final String PASSWORD = "YOUR_MYSQL_PASSWORD";

    public static void main(String[] args) {
        try (Scanner sc = new Scanner(System.in)) {
            try (Connection connection = DriverManager.getConnection(URL, USER, PASSWORD)) {
                System.out.println("Database connected successfully!\n");

                // Part (a): Insert at least three products.
                insertSampleProducts(connection);

                // Part (b): Display products in a category with quantity below 20.
                System.out.println("\n--- Part (b): Search products by category ---");
                System.out.print("Enter category: ");
                String category = sc.nextLine().trim();
                displayProductsByCategory(connection, category);

                // Part (c): Add stock to an existing product.
                System.out.println("\n--- Part (c): Update product stock ---");
                System.out.print("Enter Product ID: ");
                int stockProductId = readInt(sc);
                System.out.print("Enter quantity to add: ");
                int quantityToAdd = readInt(sc);
                updateProductStock(connection, stockProductId, quantityToAdd);

                // Part (d): Update price only when product exists and new price is positive.
                System.out.println("\n--- Part (d): Update product price ---");
                System.out.print("Enter Product ID: ");
                int priceProductId = readInt(sc);
                System.out.print("Enter new price: ");
                double newPrice = readDouble(sc);
                updateProductPrice(connection, priceProductId, newPrice);

                // Part (e): Display inventory value, then delete only a zero-stock product.
                System.out.println("\n--- Part (e): Inventory value and product deletion ---");
                displayTotalInventoryValue(connection);
                System.out.print("Enter Product ID to delete (only quantity 0 can be deleted): ");
                int deleteProductId = readInt(sc);
                deleteProductIfOutOfStock(connection, deleteProductId);

                System.out.println("\nAll parts (a) to (e) completed.");
            } catch (SQLException e) {
                System.out.println("Database error: " + e.getMessage());
                System.out.println("Check that MySQL is running, retail_db and Product table exist, and your password is correct.");
            }
        }
    }

    // Part (a): Insert three sample products using PreparedStatement.
    // Duplicate primary keys are handled without stopping the program.
    private static void insertSampleProducts(Connection con) throws SQLException {
        String sql = "INSERT INTO Product (product_id, product_name, category, quantity, price) VALUES (?, ?, ?, ?, ?)";
        Object[][] products = {
                {101, "Laptop", "Electronics", 15, 55000.0},
                {102, "Mouse", "Electronics", 10, 500.0},
                {103, "Chair", "Furniture", 25, 2500.0}
        };

        System.out.println("--- Part (a): Insert products ---");
        try (PreparedStatement ps = con.prepareStatement(sql)) {
            for (Object[] product : products) {
                ps.setInt(1, (Integer) product[0]);
                ps.setString(2, (String) product[1]);
                ps.setString(3, (String) product[2]);
                ps.setInt(4, (Integer) product[3]);
                ps.setDouble(5, (Double) product[4]);
                try {
                    ps.executeUpdate();
                    System.out.println("Product inserted: " + product[1]);
                } catch (SQLException e) {
                    if (e.getErrorCode() == 1062) {
                        System.out.println("Duplicate product ID " + product[0] + ". Product " + product[1] + " was not inserted.");
                    } else {
                        throw e;
                    }
                }
            }
        }
    }

    // Part (b): Retrieve products in the entered category where quantity < 20,
    // ordered by price in descending order.
    private static void displayProductsByCategory(Connection con, String category) throws SQLException {
        String sql = "SELECT * FROM Product WHERE category = ? AND quantity < 20 ORDER BY price DESC";
        try (PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, category);
            try (ResultSet rs = ps.executeQuery()) {
                boolean found = false;
                System.out.println("\nProducts in category '" + category + "' with quantity below 20:");
                while (rs.next()) {
                    found = true;
                    printProduct(rs);
                }
                if (!found) {
                    System.out.println("No matching products found.");
                }
            }
        }
    }

    // Part (c): Add the entered quantity to the current stock.
    private static void updateProductStock(Connection con, int productId, int quantityToAdd) throws SQLException {
        if (quantityToAdd <= 0) {
            System.out.println("Quantity to add must be greater than 0. Stock was not changed.");
            return;
        }
        String sql = "UPDATE Product SET quantity = quantity + ? WHERE product_id = ?";
        try (PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setInt(1, quantityToAdd);
            ps.setInt(2, productId);
            int rows = ps.executeUpdate();
            if (rows > 0) {
                System.out.println("Product stock updated successfully!");
            } else {
                System.out.println("Product ID not found. Stock was not updated.");
            }
        }
    }

    // Part (d): Check product existence, validate price, update, and display details.
    private static void updateProductPrice(Connection con, int productId, double newPrice) throws SQLException {
        if (newPrice <= 0) {
            System.out.println("New price must be greater than 0. Price was not updated.");
            return;
        }

        String checkSql = "SELECT * FROM Product WHERE product_id = ?";
        try (PreparedStatement check = con.prepareStatement(checkSql)) {
            check.setInt(1, productId);
            try (ResultSet rs = check.executeQuery()) {
                if (!rs.next()) {
                    System.out.println("Product ID not found. Price was not updated.");
                    return;
                }
            }
        }

        String updateSql = "UPDATE Product SET price = ? WHERE product_id = ?";
        try (PreparedStatement update = con.prepareStatement(updateSql)) {
            update.setDouble(1, newPrice);
            update.setInt(2, productId);
            update.executeUpdate();
        }

        System.out.println("Price updated successfully. Updated product details:");
        displayProductById(con, productId);
    }

    // Part (e): Calculate SUM(quantity * price) for all products.
    private static void displayTotalInventoryValue(Connection con) throws SQLException {
        String sql = "SELECT SUM(quantity * price) AS total_value FROM Product";
        try (PreparedStatement ps = con.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {
            if (rs.next()) {
                double total = rs.getDouble("total_value");
                System.out.printf("Total inventory value: %.2f%n", total);
            }
        }
    }

    // Part (e): Delete only if the product exists and its quantity is exactly zero.
    private static void deleteProductIfOutOfStock(Connection con, int productId) throws SQLException {
        String checkSql = "SELECT quantity FROM Product WHERE product_id = ?";
        try (PreparedStatement check = con.prepareStatement(checkSql)) {
            check.setInt(1, productId);
            try (ResultSet rs = check.executeQuery()) {
                if (!rs.next()) {
                    System.out.println("Product ID not found. Nothing was deleted.");
                    return;
                }
                int quantity = rs.getInt("quantity");
                if (quantity != 0) {
                    System.out.println("Product cannot be deleted because its quantity is not zero.");
                    return;
                }
            }
        }

        String deleteSql = "DELETE FROM Product WHERE product_id = ? AND quantity = 0";
        try (PreparedStatement delete = con.prepareStatement(deleteSql)) {
            delete.setInt(1, productId);
            int rows = delete.executeUpdate();
            if (rows > 0) {
                System.out.println("Product deleted successfully.");
            } else {
                System.out.println("Product could not be deleted.");
            }
        }
    }

    private static void displayProductById(Connection con, int productId) throws SQLException {
        String sql = "SELECT * FROM Product WHERE product_id = ?";
        try (PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setInt(1, productId);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    printProduct(rs);
                }
            }
        }
    }

    private static void printProduct(ResultSet rs) throws SQLException {
        System.out.printf("%d | %s | %s | %d | %.2f%n",
                rs.getInt("product_id"),
                rs.getString("product_name"),
                rs.getString("category"),
                rs.getInt("quantity"),
                rs.getDouble("price"));
    }

    private static int readInt(Scanner sc) {
        while (!sc.hasNextInt()) {
            System.out.print("Please enter a valid whole number: ");
            sc.next();
        }
        int value = sc.nextInt();
        sc.nextLine(); // consume the end-of-line character
        return value;
    }

    private static double readDouble(Scanner sc) {
        while (!sc.hasNextDouble()) {
            System.out.print("Please enter a valid number: ");
            sc.next();
        }
        double value = sc.nextDouble();
        sc.nextLine(); // consume the end-of-line character
        return value;
    }
}
