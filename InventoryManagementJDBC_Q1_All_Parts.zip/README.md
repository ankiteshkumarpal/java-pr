# Inventory Management System using JDBC and MySQL

This Maven project implements all five parts (a)–(e) of Question 1.

## Requirements
- JDK 21 (or a compatible JDK)
- Maven
- MySQL Server and MySQL Workbench
- VS Code with Java extensions (optional)

## 1. Create the database and table
1. Open MySQL Workbench and connect to your local MySQL server.
2. Open `database/schema.sql` and execute it.
3. This creates database `retail_db` and table `Product`.

## 2. Set your MySQL password
Open:
`src/main/java/com/inventory/InventoryManagement.java`

Update this line with your MySQL root password:
```java
private static final String PASSWORD = "YOUR_MYSQL_PASSWORD";
```
Keep the URL and USER unchanged unless your MySQL setup uses different values.

## 3. Run from the project folder
Open PowerShell or the VS Code terminal in the folder containing `pom.xml`, then run:
```powershell
mvn clean compile
mvn exec:java
```

## What the program does
- **(a)** Inserts three sample products using `PreparedStatement`. Duplicate product IDs are caught and reported, so running the program again does not stop at duplicate records.
- **(b)** Accepts a category and displays matching products with quantity below 20, ordered by price descending.
- **(c)** Accepts a product ID and quantity to add, then updates stock or reports that the ID was not found.
- **(d)** Accepts a product ID and new price. It updates only if the product exists and the new price is greater than zero, then displays the updated details.
- **(e)** Displays the total inventory value (`SUM(quantity * price)`), then deletes a product only when its quantity is zero.

## Sample input sequence
For the initial sample data, one possible run is:
```text
Electronics
102
20
102
650
103
```
This adds 20 to product 102's stock, changes its price to 650, then attempts to delete product 103. Product 103 has quantity 25, so it will not be deleted.

To test successful deletion, first set a product's quantity to zero in MySQL Workbench, for example:
```sql
UPDATE Product SET quantity = 0 WHERE product_id = 103;
```
Then run the Java program and enter `103` at the deletion prompt.

## Check database records
In MySQL Workbench:
```sql
USE retail_db;
SELECT * FROM Product;
```

## Important
- SQL statements go in MySQL Workbench.
- Java source code goes in `InventoryManagement.java`.
- Commands such as `mvn clean compile` go in PowerShell/VS Code terminal, from the folder containing `pom.xml`.
